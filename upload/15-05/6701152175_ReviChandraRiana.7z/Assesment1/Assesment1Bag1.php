<?php
for( $a=5;$a>0;$a--){
for($b=6; $b<=$a; $b++){
echo "&nbsp ";
}
for($c=0;$c<$a;$c++){
echo "*";
}
echo"<br>";
}
?>