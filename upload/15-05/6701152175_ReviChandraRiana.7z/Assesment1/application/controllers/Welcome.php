<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller
{
function index()
{
    $this->load->helper('html');
  //  $this->load->view('Welcome_Message');
		$this->load->library('table'); //fungsi untuk memanggil library table
		$tmpl=array('table_open'=>'<table border="1"cellpadding="4">','table_close'=>'</table>');
		$this->table->set_template($tmpl);
		$this->table->set_caption('Data Mahasiswa');
		$this->table->set_heading('NIM','Nama','Gambar');
		$this->table->add_row('6701152175','Date','<img src="<?php echo base_url();?>asset/img/images.jpg">');
		$this->table->add_row('6701152176','Seryuu','<img src="<?php echo base_url();?>asset/img/images.jpg">');
		$this->table->add_row('6701152177','Genta','<img src="<?php echo base_url();?>asset/img/images.jpg">');
			$a=$this->table->generate();
			$data['table']=$a;
			$data['heading']=heading('Biodata Pengguna',1);
			$this->load->view('uri');
			$this->load->view('view_html',$data);
			$this->load->view('form_view');
    }
}
?>