<?php
echo form_input('username','admin') . "\n";
echo"<br />";
$data = array(
    'name'=>'password',
    'placeholder'=>'Your password',
    'required'=>'required'
);

echo form_input($data) . "\n";
echo"<br />";
echo form_textarea('message') . "\n";
echo"<br />";
echo form_submit('submit','login');
?>