<a href="<?php echo base_url();?>index.php/facebook">Facebok</a>

