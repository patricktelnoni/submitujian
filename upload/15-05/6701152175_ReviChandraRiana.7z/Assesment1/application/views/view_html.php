<html>
<head>
    <title>Assesment1</title>
</head>
<body bgcolor=white>
    <font color=black>
    <h2>
    <?php echo $heading?>
    <p>
    </font>
    <hr>
    <?php echo $table?>
    </p>
    </h2>
</body>
</html>
