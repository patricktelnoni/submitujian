
<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>CodeIgniter admin</title>
        <meta charset="utf-8">
        <link href="<?php echo base_url();?>
        assets/css/custom.min.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <font size="6">Data Mahasiswa</font>
    </body>
</html>
