<html>
<head>
	<title>Latihan Library</title>
</head>
<body bgcolor=white>
	<font color=black>
	<h2>
	<?php echo $heading?>
	
	</font>
	List mahasiswa :
	<hr>
	<?php echo $table?>
	</p>
	</h2>
</body>
</html>