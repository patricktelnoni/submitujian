<html>
<head>
<title>Syafiq Helper</title>
</head>
<body>
<h3>Contoh Helper Buatan Syafiq</h3>
<p>Sekarang bulan : <?php echo bulan_indonesia(date('m'));?></p>
</body>
</html>