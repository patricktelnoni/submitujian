<?php 
 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
 
function print_debug($array) {
    echo "<pre>";
    print_r($array); 
    exit; 
}
 
?>