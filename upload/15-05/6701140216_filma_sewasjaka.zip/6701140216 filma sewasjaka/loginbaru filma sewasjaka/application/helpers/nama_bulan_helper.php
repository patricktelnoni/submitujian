<?php if (! defined('BASEPATH'))exit('No direct script access allowed');
/**
*Bulan Indonesia Helper
*@peckage CodeIgniter
*@subpackage Helpers
*@category Helpers
*@authoe oyazhurychna
*@link http://ozs.web.id
*/

if(! function_exist('bulan_helper'))
{
	function bulan_indonesia($bulan)
	{
		$nama_bulan=array(
		'01'=>'januari',
		'02'=>'februari',
		'03'=>'maret',
		'04'=>'april',
		'05'=>'mei'
		);
		return$nama_bulan[$bulan];
	}
}
?>