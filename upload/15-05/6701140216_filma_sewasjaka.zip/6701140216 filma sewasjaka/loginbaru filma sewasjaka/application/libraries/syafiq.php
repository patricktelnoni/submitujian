<?php 
 
class syafiq{
 
	function nama_saya(){
		echo "Nama saya adalah Syafiq Authory !";
	}
 
	function nama_kamu($nama){
		echo "Nama kamu adalah ". $nama ." !";
	}
}

?>

