<?php

class MY_Dosen extends CI_Controller{
    public function __construct(){
        parent::__construct();
        echo "HELLO WORLD CUSTOM DOSEN";
    }
}

?>