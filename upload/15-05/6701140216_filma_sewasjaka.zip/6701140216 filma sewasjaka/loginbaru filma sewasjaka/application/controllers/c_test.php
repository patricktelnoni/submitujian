<?php
class c_test extends MY_Dosen {
 public function __construct(){
    parent::__construct();
}
public function _remap($method){
    switch($method)
    {
        case 'about-diri-saya'://yang dipanggil di url(segmen 5)
            $this->about_me(); //yang dipanggil dalam controller
            break;             //nama method bebas
        case 'sukses':
            $this->display_successful_message();
            break;
        default:
            $this->page_not_found();
            break;
    }
}
public function about_me(){
    echo "<br> About Me";
}
public function display_successful_message(){
    echo "<br> success";
}
public function page_not_found(){
    echo "<br> Not Found";
}
}

?>
