<?php 
    function contoh_1() { 
       $this->load->helper('debug');
       $array = array('medan','jakarta','bandung');
       print_debug($_COOKIE);
    }
?>