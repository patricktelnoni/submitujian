<?php

class coba extends ci_controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
		$this->load->view('v_coba');
		$this->load->helper('bulan_indonesia');
	}
}
?>