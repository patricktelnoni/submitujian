<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class authory extends CI_Controller {
	
	function index(){
		$this->load->library('syafiq');
		$this->syafiq->nama_saya();
                echo "<br/>";
                $this->syafiq->nama_kamu("Manil");
	}
 
}
?>