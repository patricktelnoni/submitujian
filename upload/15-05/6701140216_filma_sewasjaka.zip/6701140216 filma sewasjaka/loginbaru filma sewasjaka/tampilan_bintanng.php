<?php
	if(isset($_POST['submit'])){
	$bin = $_POST['bintang'];
	
	for($a =1; $a <= $bin; $a++){
		for($b = 1; $b <= $a; $b++){
			echo"*";
			}
			echo"<br>"
	}
	}
	?>