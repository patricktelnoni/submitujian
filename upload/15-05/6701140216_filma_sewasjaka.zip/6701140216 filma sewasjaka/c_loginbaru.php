<?php
defined('BASEPATH') OR exit('no direct script access allowed');

class c_loginbaru extends CI_Controller{
    public function login(){
        if(isset($_POST['submit'])){
            
            $username=$this->input->post('username');
            $pass=$this->input->post('pass');
            
        if($NIM=='admin' && $nm=='admin'){
                
                 redirect('c_loginbaru/display');
        }else{
				$this->load->view('v_loginbaru');
			}
		}else{
            $this->load->view('v_loginbaru');
        }
	}
	public function display(){
		
	$this->load->library('table'); //fungsi untuk memanggil library table
	
		$tmpl = array('table_open'=>'<table border="1" cellpadding="4">','table_close'=>'</table>');
			$this->table->set_template($tmpl);
			$this->table->set_caption('Data Mahasiswa');
			$this->table->set_heading('NIM', 'Nama');
			$this->table->add_row('351684','riswan');
			$this->table->add_row('541685','arya');
			$this->table->add_row('546845','Sinchan');
		$a = $this->table->generate();
		$data['table']=$a;
		$data['heading']=heading('Biodata Mahasiswa',1);
			$this->load->view('view_html', $data);
	}
}

?>

