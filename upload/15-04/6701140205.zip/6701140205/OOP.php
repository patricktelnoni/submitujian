<html>
<body>

<h2>INPUT DATA </h2>
<form method="post">
<table border=0>
<tr>
	<td>Input Angka :</td>
	<td><input type="text" name="input"></td>
</tr>
<tr>
	<td><input type="submit" name="input" value="Input"></td>
	</tr>
</table>
</form>

<?php 
	for($a=0;$a<=4;$a++){ 
		for($b=$a;$b>=1;$b--) { 
			echo "*";}
				echo "<br>";}
?>
</body>
</html>